package udalosti;

import ludia.HracVSach;

public interface RegistraciaDoTurnaju {
	void registracia(HracVSach ucastnik);
}