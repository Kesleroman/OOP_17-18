package urovne;

public class DruhaTrieda extends Uroven{

	public DruhaTrieda(int rating) {
		super(rating);
	}
	
	public DruhaTrieda() {
		super(1600);
	}

	public String toString() {
		return "Druha Trieda";
	}
}
