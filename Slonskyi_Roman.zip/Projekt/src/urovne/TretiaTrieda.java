package urovne;

public class TretiaTrieda extends Uroven {
	
	public TretiaTrieda(int rating) {
		super(rating);
	}
	
	public TretiaTrieda() {
		super(1400);
	}

	public String toString() {
		return "Tretia Trieda";
	}
}
