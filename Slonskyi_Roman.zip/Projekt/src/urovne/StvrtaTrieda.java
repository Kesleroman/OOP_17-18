package urovne;

public class StvrtaTrieda extends Uroven {
	
	public StvrtaTrieda(int rating) {
		super(rating);
	}
	
	public StvrtaTrieda() {
		super(1000);
	}

	public String toString() {
		return "Stvrta Trieda";
	}
}
