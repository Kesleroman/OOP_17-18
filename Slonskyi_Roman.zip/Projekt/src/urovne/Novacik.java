package urovne;

public class Novacik extends Uroven {
	
	public Novacik(int rating) {
		super(rating);
	}
	
	public Novacik() {
		super(0);
	}

	public String toString() {
		return "Novacik";
	}
}
