package urovne;

public class PrvaTrieda extends Uroven {
	
	public PrvaTrieda(int rating) {
		super(rating);
	}
	
	public PrvaTrieda() {
		super(1800);
	}

	public String toString() {
		return "Prva Trieda";
	}
}
