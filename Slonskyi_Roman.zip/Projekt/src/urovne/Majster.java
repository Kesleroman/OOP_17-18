package urovne;

public class Majster extends Uroven {

	public Majster(int rating) {
		super(rating);
	}
	
	public Majster() {
		super(2000);
	}

	public String toString() {
		return "Majster";
	}
	
}
