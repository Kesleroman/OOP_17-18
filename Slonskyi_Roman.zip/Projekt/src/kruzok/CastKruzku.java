package kruzok;

import java.util.ArrayList;

import ludia.HracVSach;

public interface CastKruzku {
	ArrayList<? extends HracVSach>vybratHracov();
}